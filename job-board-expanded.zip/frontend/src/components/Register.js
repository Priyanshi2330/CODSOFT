import React, { useState } from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

export default function Register({ onRegister }){
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'candidate' });
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    try {
      const res = await API.post('/auth/register', form);
      onRegister(res.data);
      nav('/');
    } catch(err){
      alert(err.response?.data?.message || 'Register failed');
    }
  }

  return (
    <form onSubmit={submit}>
      <h2>Register</h2>
      <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
      <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required />
      <input placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} required />
      <select value={form.role} onChange={e=>setForm({...form, role: e.target.value})}>
        <option value="candidate">Candidate</option>
        <option value="employer">Employer</option>
      </select>
      <button type="submit">Register</button>
    </form>
  );
}
