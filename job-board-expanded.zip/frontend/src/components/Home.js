import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <div>
      <h1>Welcome to JobBoard</h1>
      <p>Find jobs or post openings. Built with React + Node + MongoDB.</p>
      <Link to="/jobs" className="btn">Browse Jobs</Link>
    </div>
  );
}
