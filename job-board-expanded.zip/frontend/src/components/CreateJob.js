import React, { useState } from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

export default function CreateJob({ user }){
  const navigate = useNavigate();
  const [form, setForm] = useState({ title:'', company:'', location:'', type:'Full-time', description:'', salary:'' });
  async function submit(e){
    e.preventDefault();
    if(!user) return alert('Login as employer to post');
    try {
      await API.post('/jobs', form);
      alert('Job posted');
      navigate('/jobs');
    } catch(err){
      alert(err.response?.data?.message || 'Error');
    }
  }
  return (
    <div>
      <h2>Post Job</h2>
      <form onSubmit={submit}>
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} required />
        <input placeholder="Company" value={form.company} onChange={e=>setForm({...form, company:e.target.value})} required />
        <input placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} />
        <input placeholder="Type" value={form.type} onChange={e=>setForm({...form, type:e.target.value})} />
        <input placeholder="Salary" value={form.salary} onChange={e=>setForm({...form, salary:e.target.value})} />
        <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
        <button type="submit">Post</button>
      </form>
    </div>
  );
}
