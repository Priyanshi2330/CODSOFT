import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar({ user, onLogout }){
  return (
    <nav className="nav">
      <div className="nav-left">
        <Link to="/">JobBoard</Link>
        <Link to="/jobs">Jobs</Link>
        {user?.role === 'employer' && <Link to="/create-job">Post Job</Link>}
        {user?.role === 'employer' && <Link to="/employer/jobs">My Jobs</Link>}
      </div>
      <div className="nav-right">
        {user ? (
          <>
            <span>Hi, {user.name}</span>
            <button onClick={onLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
