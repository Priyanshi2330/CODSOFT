import React, { useEffect, useState } from 'react';
import API from '../api';
import { Link } from 'react-router-dom';

export default function JobsList({ employerView }){
  const [jobs, setJobs] = useState([]);
  const [q, setQ] = useState('');
  useEffect(()=> { fetchJobs(); }, []);
  async function fetchJobs(query){
    try {
      if(employerView){
        const res = await API.get('/jobs/mine/list');
        setJobs(res.data);
      } else {
        const res = await API.get('/jobs', { params: { q: query || '' }});
        setJobs(res.data);
      }
    } catch(err){
      setJobs([]);
    }
  }
  const onSearch = (e) => { e.preventDefault(); fetchJobs(q); };

  return (
    <div>
      <h2>{employerView ? 'My Posted Jobs' : 'Job Listings'}</h2>
      {!employerView && (
        <form onSubmit={onSearch}>
          <input placeholder="Search jobs..." value={q} onChange={e=>setQ(e.target.value)} />
          <button>Search</button>
        </form>
      )}
      {jobs.length === 0 ? <p>No jobs found</p> :
        jobs.map(job => (
          <div key={job._id} className="job-card">
            <h3>{job.title}</h3>
            <p className="small">{job.company} — {job.location}</p>
            <p>{job.description?.slice(0,200)}...</p>
            <Link to={`/jobs/${job._id}`}>View</Link>
          </div>
        ))
      }
    </div>
  );
}
