import React, { useState } from 'react';
import API from '../api';

export default function ApplyForm({ jobId }){
  const [candidateName, setCandidateName] = useState('');
  const [candidateEmail, setCandidateEmail] = useState('');
  const [message, setMessage] = useState('');
  const [resume, setResume] = useState(null);
  const [status, setStatus] = useState('');

  async function onSubmit(e){
    e.preventDefault();
    const fd = new FormData();
    fd.append('candidateName', candidateName);
    fd.append('candidateEmail', candidateEmail);
    fd.append('message', message);
    if(resume) fd.append('resume', resume);
    try {
      const res = await API.post(`/jobs/${jobId}/apply`, fd, { headers: { 'Content-Type': 'multipart/form-data' }});
      setStatus('Applied successfully');
      setCandidateName(''); setCandidateEmail(''); setMessage(''); setResume(null);
    } catch(err){
      setStatus('Apply failed');
    }
  }

  return (
    <form onSubmit={onSubmit}>
      <input value={candidateName} onChange={e=>setCandidateName(e.target.value)} placeholder="Your name" required />
      <input value={candidateEmail} onChange={e=>setCandidateEmail(e.target.value)} placeholder="Your email" required />
      <textarea value={message} onChange={e=>setMessage(e.target.value)} placeholder="Message (optional)"></textarea>
      <input type="file" onChange={e=>setResume(e.target.files[0])} accept=".pdf,.doc,.docx" />
      <button type="submit">Submit Application</button>
      <div>{status}</div>
    </form>
  );
}
