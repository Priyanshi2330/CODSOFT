import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api';
import ApplyForm from './ApplyForm';

export default function JobDetail({ user }){
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [applications, setApplications] = useState([]);
  useEffect(()=> { API.get(`/jobs/${id}`).then(r=> setJob(r.data)).catch(()=>{}); }, [id]);

  async function loadApplications(){
    try {
      const res = await API.get(`/jobs/${id}/applications`);
      setApplications(res.data);
    } catch(err){ /* ignore */ }
  }

  if(!job) return <p>Loading...</p>;
  return (
    <div>
      <h2>{job.title}</h2>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p>{job.description}</p>

      <h3>Apply for this job</h3>
      <ApplyForm jobId={id} />

      <h3>Applications (count)</h3>
      <p>{job.applications?.length || 0} applications</p>

      {user?.user?.role === 'employer' && (
        <div>
          <button onClick={loadApplications}>Load Applications</button>
          {applications.map((a,idx)=>(
            <div key={idx} style={{border:'1px solid #ccc', padding:8, margin:8}}>
              <div><strong>{a.candidateName}</strong> ({a.candidateEmail})</div>
              <div className="small">Applied: {new Date(a.appliedAt).toLocaleString()}</div>
              <div>{a.message}</div>
              {a.resumeUrl && <div><a href={`http://localhost:5000${a.resumeUrl}`} target="_blank" rel="noreferrer">Resume</a></div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
