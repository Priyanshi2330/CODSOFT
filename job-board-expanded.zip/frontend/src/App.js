import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import JobsList from './components/JobsList';
import JobDetail from './components/JobDetail';
import CreateJob from './components/CreateJob';
import Login from './components/Login';
import Register from './components/Register';
import { setToken } from './api';

function App(){
  const [auth, setAuth] = useState(() => {
    try { return JSON.parse(localStorage.getItem('auth')); } catch(e){ return null; }
  });
  useEffect(()=> { setToken(auth?.token); }, [auth]);
  const handleLogin = (authData) => {
    localStorage.setItem('auth', JSON.stringify(authData));
    setAuth(authData);
  };
  const handleLogout = () => { localStorage.removeItem('auth'); setAuth(null); setToken(null); };

  return (
    <div>
      <Navbar user={auth?.user} onLogout={handleLogout} />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/jobs" element={<JobsList/>} />
          <Route path="/jobs/:id" element={<JobDetail user={auth} />} />
          <Route path="/create-job" element={<CreateJob user={auth} />} />
          <Route path="/employer/jobs" element={<JobsList employerView={true} />} />
          <Route path="/login" element={<Login onLogin={handleLogin}/>} />
          <Route path="/register" element={<Register onRegister={handleLogin}/>} />
        </Routes>
      </div>
    </div>
  );
}
export default App;
