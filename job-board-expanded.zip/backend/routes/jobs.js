const express = require('express');
const router = express.Router();
const Job = require('../models/Job');
const auth = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// multer setup to save uploads to /uploads
const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, uploadDir);
  },
  filename: function(req, file, cb){
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + '-' + Math.round(Math.random()*1E9) + ext);
  }
});
const upload = multer({ storage });

// create job (employer)
router.post('/', auth, async (req,res) => {
  try {
    if (req.user.role !== 'employer') return res.status(403).json({ message: 'Only employer can post jobs' });
    const job = new Job({ ...req.body, postedBy: req.user._id });
    await job.save();
    res.json(job);
  } catch(err){ res.status(500).json({ message: err.message }); }
});

// list jobs with optional search ?q=developer
router.get('/', async (req,res) => {
  try {
    const q = req.query.q || '';
    const filter = q ? {
      $or: [
        { title: { $regex: q, $options: 'i' } },
        { company: { $regex: q, $options: 'i' } },
        { location: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } }
      ]
    } : {};
    const jobs = await Job.find(filter).sort({ createdAt: -1 }).limit(100);
    res.json(jobs);
  } catch(err){ res.status(500).json({ message: err.message }); }
});

// get job detail
router.get('/:id', async (req,res) => {
  try {
    const job = await Job.findById(req.params.id).populate('postedBy', 'name email');
    if(!job) return res.status(404).json({ message: 'Not found' });
    res.json(job);
  } catch(err){ res.status(500).json({ message: err.message }); }
});

// apply to job (upload resume)
router.post('/:id/apply', upload.single('resume'), async (req,res) => {
  try {
    const job = await Job.findById(req.params.id);
    if(!job) return res.status(404).json({ message: 'Not found' });

    const { candidateName, candidateEmail, message } = req.body;
    let resumeUrl = '';
    if(req.file){
      resumeUrl = `/uploads/${req.file.filename}`;
    }
    job.applications.push({ candidateName, candidateEmail, resumeUrl, message });
    await job.save();
    res.json({ message: 'Applied', application: job.applications[job.applications.length -1] });
  } catch(err){ res.status(500).json({ message: err.message }); }
});

// employer: list own jobs
router.get('/mine/list', auth, async (req, res) => {
  try {
    const jobs = await Job.find({ postedBy: req.user._id }).sort({ createdAt: -1 });
    res.json(jobs);
  } catch(err){ res.status(500).json({ message: err.message }); }
});

// employer: get applications for a job (protected)
router.get('/:id/applications', auth, async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if(!job) return res.status(404).json({ message: 'Not found' });
    if(job.postedBy.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Forbidden' });
    res.json(job.applications || []);
  } catch(err){ res.status(500).json({ message: err.message }); }
});

module.exports = router;
