const mongoose = require('mongoose');

const ApplicationSchema = new mongoose.Schema({
  candidateName: String,
  candidateEmail: String,
  resumeUrl: String,
  message: String,
  appliedAt: { type: Date, default: Date.now }
});

const JobSchema = new mongoose.Schema({
  title: String,
  company: String,
  location: String,
  type: String,
  description: String,
  salary: String,
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  applications: [ApplicationSchema]
}, { timestamps: true });

module.exports = mongoose.model('Job', JobSchema);
