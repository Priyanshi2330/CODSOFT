# Job Board Expanded

This is an expanded Job Board starter with backend and frontend code.

Run backend: cd backend && npm install && npm run dev
Run frontend: cd frontend && npm install && npm start
